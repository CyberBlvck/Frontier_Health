from flask import Flask, render_template, request, redirect, url_for, session
import psycopg2
import bcrypt
from datetime import timedelta

app = Flask(__name__)
app.secret_key = '27fLavorS' # 07/12/19  - 15/03/22
app.permanent_session_lifetime = timedelta(days=1) #define permanent time periodas

#connecction function
def dbconn():
    conn = psycopg2.connect(host="localhost", dbname="Frontier_health", user="postgres", password="gambino")
    return conn

#render html
@app.route('/')
def index():
    return render_template('signup.html')

#actual route
@app.route('/submit', methods=['POST'])
def submit():
    conn = dbconn()
    cur = conn.cursor()


    #values
    name = request.form['name']
    email = request.form['email']
    password = request.form['password']

    #encrypwization
    def crypwalk (password):
        passhash = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
        return passhash.decode('utf-8')  # Convert bytes to string

    passwization = crypwalk(password)    
    
    #SQLing
    cur.execute("""INSERT INTO users_table (name, email, password)
            VALUES (%s,%s,%s);""",(name, email, passwization)
        )
    
    #as wise
    conn.commit()
    conn.close()
    return 'Registration Successful'

#loginting
@app.route('/login', methods=['POST','GET'])
def login():
    conn = dbconn()
    with conn.cursor() as cur:
        if request.method == "POST":
            email = request.form['email'] 
            password = request.form['password']

            #SQLnshit
            cur.execute("SELECT email, name, password FROM users_table WHERE email = %s;",(email,))
            data = cur.fetchone() #play fetch with the db
            if data: #fyi @data is a tuple...
                stemail, name, stpass = data # see
                stpass = stpass
                if bcrypt.checkpw(password.encode('utf-8'), stpass.encode('utf-8')):
                    
                    #session
                    session.permanent = True #set permanent session
                    session['user'] = name # Correct way to set session variables
                    return render_template('dash.html')

                elif "user" in session:
                    return render_template('dash.html')
                else:
                    print ("password incorrect")
            else:
                return "No such email"
        return render_template ('login.html')

@app.route("/logout")
def logout():
    session.pop('user', None)
    return render_template('login.html')

        
#kaya this item
if __name__ == '__main__':
    app.run(debug=True)


